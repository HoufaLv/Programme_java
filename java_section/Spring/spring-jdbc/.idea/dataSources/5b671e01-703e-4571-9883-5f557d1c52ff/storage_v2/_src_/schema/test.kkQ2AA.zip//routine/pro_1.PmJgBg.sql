create procedure pro_1()
  BEGIN
select * from products;
END;

