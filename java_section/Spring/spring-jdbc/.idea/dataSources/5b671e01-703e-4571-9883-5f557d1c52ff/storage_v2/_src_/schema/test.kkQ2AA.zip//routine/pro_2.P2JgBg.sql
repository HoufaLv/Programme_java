create procedure pro_2()
  BEGIN
insert into t_stu (`name`,`password`) values('james','123456');
update t_stu set name = 'lebron' where id = '1004';
END;

