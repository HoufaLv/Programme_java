create view v_cust_desc as
  select
    `test`.`customers`.`cust_id`      AS `cust_id`,
    `test`.`customers`.`cust_name`    AS `cust_name`,
    `test`.`customers`.`cust_address` AS `cust_address`,
    `test`.`customers`.`cust_city`    AS `cust_city`,
    `test`.`customers`.`cust_state`   AS `cust_state`,
    `test`.`customers`.`cust_zip`     AS `cust_zip`,
    `test`.`customers`.`cust_country` AS `cust_country`,
    `test`.`customers`.`cust_contact` AS `cust_contact`,
    `test`.`customers`.`cust_email`   AS `cust_email`
  from `test`.`customers`
  order by `test`.`customers`.`cust_id` desc;

