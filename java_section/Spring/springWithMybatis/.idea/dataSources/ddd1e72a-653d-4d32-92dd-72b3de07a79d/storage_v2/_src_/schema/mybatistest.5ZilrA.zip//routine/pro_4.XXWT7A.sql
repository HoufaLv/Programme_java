create procedure pro_4(IN stuname varchar(255), IN stupassword varchar(255))
  BEGIN
INSERT into t_stu (name,password) values (stuname,stupassword);
END;

