create procedure pro_3(OUT maxp decimal(8, 2), OUT minp decimal(8, 2))
  BEGIN
SELECT MAX(PROD_PRICE) INTO maxp from products;
SELECT MIN(PROD_PRICE) into minp from products;
END;

