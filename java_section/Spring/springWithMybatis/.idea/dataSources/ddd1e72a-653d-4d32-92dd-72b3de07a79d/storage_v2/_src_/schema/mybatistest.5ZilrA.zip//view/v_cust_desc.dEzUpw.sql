create view v_cust_desc as
  select
    `mybatistest`.`customers`.`cust_id`      AS `cust_id`,
    `mybatistest`.`customers`.`cust_name`    AS `cust_name`,
    `mybatistest`.`customers`.`cust_address` AS `cust_address`,
    `mybatistest`.`customers`.`cust_city`    AS `cust_city`,
    `mybatistest`.`customers`.`cust_state`   AS `cust_state`,
    `mybatistest`.`customers`.`cust_zip`     AS `cust_zip`,
    `mybatistest`.`customers`.`cust_country` AS `cust_country`,
    `mybatistest`.`customers`.`cust_contact` AS `cust_contact`,
    `mybatistest`.`customers`.`cust_email`   AS `cust_email`
  from `mybatistest`.`customers`
  order by `mybatistest`.`customers`.`cust_id` desc;

