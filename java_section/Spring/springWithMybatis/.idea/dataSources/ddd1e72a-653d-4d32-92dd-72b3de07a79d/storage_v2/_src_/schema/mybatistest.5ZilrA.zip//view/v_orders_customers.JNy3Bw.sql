create view v_orders_customers as
  select
    `ord`.`order_num`     AS `order_num`,
    `ord`.`order_date`    AS `order_date`,
    `ord`.`cust_id`       AS `cust_id`,
    `cust`.`cust_name`    AS `cust_name`,
    `cust`.`cust_address` AS `cust_address`
  from `mybatistest`.`orders` `ord`
    join `mybatistest`.`customers` `cust`
  where (`ord`.`cust_id` = `cust`.`cust_id`);

